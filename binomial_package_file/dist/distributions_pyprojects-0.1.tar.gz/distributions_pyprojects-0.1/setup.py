from setuptools import setup

setup(name='distributions_pyprojects',
      version='0.1',
      description='Gaussian and Binomial distributions_pyprojects',
      packages=['distributions_pyprojects'],
      author='Lily Ng',
      author_email='lilyng15@outlook.com',
      zip_safe=False)
